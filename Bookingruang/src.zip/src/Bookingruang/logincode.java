/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Viranda
 */
/*import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class logincode {
    static String driver = ("com.mysql.jdbc.Driver");
    static String url ="jdbc:mysql://localhost/jadwal";
    static String user = "root";
    static String pw = "";
    public static Connection con;
    public static Statement stm;
    
    
    public static void main (String [] args){
        try{
            con = DriverManager.getConnection(url,user,pw);
            stm = con.createStatement();
        }
        catch(Exception e){
            System.err.println(e.getMessage());
        }
    }
}*/